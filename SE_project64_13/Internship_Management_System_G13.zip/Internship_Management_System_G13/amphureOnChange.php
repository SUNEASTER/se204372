<?php
    require_once("./models/districtModel.php");
    $Amphure_Id = $_GET['Amphure_Id'];
    if($Amphure_Id == 0)
        $text = "กรุณาเลือกอำเภอก่อน";
    else
        $text = "เลือกตำบล";
    $District_list = District::getByAmphure($Amphure_Id);
    echo "<option hidden='hidden' value=0>$text</option>";
    foreach($District_list as $district){
        echo "<option value=$district->District_Id>$district->District_NameTH</option>";
}
?>