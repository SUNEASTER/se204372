<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    .wrapper .section .table{
        text-align: center;
        color: #b31f1c;
    }

    .wrapper .section .table h1{
        margin-top: 60px;
    }

    /* -ข้อความ */
    .wrapper .section .content{
        
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
        margin-left: 17px;
        margin-right: 70px;
        word-wrap: break-word;
    }

    .wrapper .section .contentx{
        font-size: 20px;
        color: black;
        text-align: right;
        flex-direction: row;
    }

    /* สเตตัส ของผู้ป่วย สร้างเพิ่มได้ b1 b2 b3 ......*/
    /* เขียว */
    .wrapper .section .content .b1{
        color: green;
    }
    /* แดง */    
    .wrapper .section .content .b2{
        color: red;

    }

    /* รายละเอียดเพิ่มเติม */
    .wrapper .section .contentx .d{
        color: rgb(7, 105, 185);
        text-decoration: underline;
    }

    /* 2. กล่องกลาง */
    .wrapper .section .flexbox{
        display: flex;
        box-sizing: border-box;
        flex-direction: column;
        justify-content: space-evenly;
        flex-wrap: wrap;
        border: 2px solid #6f6d6d; 
        margin-bottom: 15px;
        padding: 20px 20px 20px 20px;
        border-radius: 24px;
        background-color:#E5E4E2;
    }

    /* 3.กล่องใหญ่ */
    .wrapper .section .flexbox2{
        margin: 5% 5%;
        margin-top: 50px;
        flex-direction: column;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }

    /* กล่องเล็ก */
    .wrapper .section .box{
        display: block;
        box-sizing: border-box;
        width: 100%;
        /* border: 3px solid black; */
    }

    /* ทำ กล่องเล็กสุด เป็นกล่องเล็ก */
    .wrapper .section .flexbox-in{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }
    .wrapper .section .box-in  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 50%;
    }

    /* กล่องเล็กสุด 2 กล่อง (อนุมัติไม่-อนุมัติ) */
    .wrapper .section .flexbox-inx{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        /* border: 3px solid black; */
    }

    .wrapper .section .box-inx  {
        display: block;
        box-sizing: border-box;
        justify-content: center;
        /* border: 3px solid black; */
    }

    button{
        background-color:#ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    .wrapper .section .success {
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .success:hover {
        background-color: #04AA6D;
        color: white;
    }

    /* Red */
    .wrapper .section .reject {
        border-color: #f44336;
        color: red;
    }

    .wrapper .section .reject:hover {
        background: #f44336;
        color: white;
    }

    input[type=text].search{
        width: 84.9%;                     /*edit*/
        box-sizing: border-box;
        height: 51px;
        border: 3px solid black;
        border-radius: 4px;
        font-size: 16px;
        background-color: white;
        background-image: url('searchicon.png');
        background-position: 10px 10px; 
        background-repeat: no-repeat;
        padding: 12px 12px 12px 30px;
        margin: 30px 0px 0px 30px;
    }

    form.search .button1{
        float: right;
        height: 51px;
        width: 10%;
        /* border: 3px solid darkred; */
        padding: 12px 12px 12px 12px;
        margin: 30px 30px 20px 0px;
        background: #b31f1c;
        color: white;
        font-size: 17px;
        cursor: pointer;
    }

    form.search .button1:hover {
        background: red;
    }

    a{
        color: #C21807;
    }

    .wrapper .section .page{
        display: flex;
        justify-content: space-around;
    }

        /* Dropdown */

    .filter{    
        display: flex;
        justify-content: space-around;
        /*border: 3px solid darkred;*/
    }
    
    .label_DD{
        display: flex;
        align-items: center;
        flex-direction: row; 
        /*border: 3px solid darkred;*/
        width: 30%;
        justify-content:center;
    }

    .custom-select {
        position: relative;
        margin-left:5px;
        /*border: 3px solid darkred;*/
        width: 200px;
        text-align:center;
    }

    
    .custom-select select {
        background-color: #ac2421 ;
        color: white;
        padding: 12px;
        width: 200px;
        border: none;
        font-size: 20px;
        box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
        -webkit-appearance: button;
        appearance: button;
        outline: none;
        border-radius: 10px;
    }

    /*------------------------------------*/
</style>

<div class="section">   <!-- แก้ในนี้ --> 
    <div class="table">
        <h1> ตรวจสอบสถานะการยื่นคำร้อง  </h1>
    </div>

    <div>
        <form class = "search" method = "get" action = "">
            <div>    
                <input type="hidden" name="controller" value="checkStatus">
                <input type="hidden" name="action" value="index">
                <input type="text" id="key" name="key" class="search" placeholder="ค้นหา..." value="<?php echo $key; ?>">
                <button style=" border-radius: 7px;" class="button1"  type="submit" >ค้นหา</button>
            </div>
            <br>
            <div class="filter">
            <div class="label_DD">
                    <b style="font-size: 20px;">รูปแบบใบคำร้อง :</b>
                     <div class="custom-select" > 
                        <select name="requestType" id="Request_Type" onchange="OnChange()">
                            <?php 
                                foreach($Request_Type_DropDown as $Request_Type){
                                    echo "<option value=$Request_Type";
                                    if($Request_Type == $requestType)
                                        echo " selected = 'selected'";
                                    echo ">$Request_Type</option>";
                                }?>
                        </select>
                     </div> 
                </div>
                <div class="label_DD"> 
                <b style="font-size: 20px;">สถานะ :</b>
                     <div class="custom-select"> 
                        <select name="requestStatus" id="Request_Status" onchange="OnChange()">
                            <?php 
                                foreach($Request_Status_DropDown as $Request_Status){
                                    echo "<option value=$Request_Status";
                                    if($Request_Status == $requestStatus)
                                        echo " selected = 'selected'";
                                    echo ">$Request_Status</option>";
                                }?>
                        </select>
                     </div> 
                </div>
                <div class="label_DD">
                    <b style="font-size: 20px;">ปีการศึกษา :</b>
                     <div class="custom-select"> 
                        <select name="academicYear" id="Academic_Year" onchange="OnChange()">
                            <?php echo "<option value=ทั้งหมด>ทั้งหมด</option>";
                                foreach($Academic_Year_DropDown as $Academic_Year){
                                    echo "<option value=$Academic_Year";
                                    if($Academic_Year == $academicYear)
                                        echo " selected = 'selected'";
                                    echo ">$Academic_Year</option>";
                                }?>
                        </select>
                     </div>            
                </div>
            </div>
        
        </form>


    </div>
    
    <div class="flexbox2">
        <?php foreach($requestForm_list as $requestForm) {?>
            <form action="" method="GET">
                <input type="hidden" name="controller" value="checkStatus"/>
                <div class="flexbox">
                    <div class="box">
                        <div class="flexbox-in">
                            <div class="box-in">
                                <div class="content">
                                    <b> รูปแบบใบคำร้อง : </b>
                                    <b <?php if($requestForm->Request_Type == "ฝึกงาน"){
                                        echo " style = 'color:  #723C2A'";
                                    }
                                    else if($requestForm->Request_Type == "สหกิจศึกษา"){
                                        echo " style = 'color: #191970'";
                                    }
                                    ?>><?php echo $requestForm->Request_Type; ?></b>
                                </div>
                            </div>
                            <div class="box-in">
                                <div class="contentx">
                                    <b class="d"><a href="?controller=checkStatus&action=detail&requestFormID=<?php echo $requestForm->Request_Id; ?>">รายละเอียดเพิ่มเติม >></a></b>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="content">
                            <b>ปีการศึกษาที่ยื่น : <?php echo $requestForm->Academic_Year; ?></b>
                        </div>
                    </div>
                    <br>
                    <div class="box">
                        <div class="content">
                            <b>สถานประกอบการ : <?php echo $requestForm->Company->Name; ?> </b>
                        </div>
                    </div>
                    <div class="box">
                        <div class="content">
                            <b>สถานะ : </b>
                            <b <?php if($requestForm->Request_Status == "อนุมัติ"){
                                echo " style = 'color: green' ";
                            }
                            else if($requestForm->Request_Status == "ไม่อนุมัติ"){
                                echo " style = 'color: #D30000'";
                            }
                            else if($requestForm->Request_Status == "อยู่ระหว่างดำเนินการพิจารณา"){
                                    echo " style = 'color:  #DFA006'";
                            }?>><?php echo $requestForm->Request_Status; ?></b>
                        </div>
                    </div>
                    <div class="box" <?php if($requestForm->Request_Status != "ไม่อนุมัติ") echo " style='display: none'; ";?>>
                        <div class="content">
                            <b>เหตุผล : <?php echo $requestForm->Reject_Reason; ?></b>
                        </div>
                    </div>
                    <br>
                    <div class="box">
                        <div class="content">
                            <b>วันที่ยื่นคำร้อง: <?php echo date_format(date_create($requestForm->CreateDate),"d/m/Y")?></b>
                        </div>
                    </div>
                </div>
            </form>
        <?php }?>   
        <br>
        <div class="page">
            <div <?php if($page <= 1) echo " style = 'visibility:hidden' "; ?> ><b ><a style=text-decoration:underline; href="?controller=checkStatus&action=index<?php if($key != "") echo "&key=$key"; if($requestType != "ทั้งหมด") echo "&requestType=$requestType"; if($requestStatus != "ทั้งหมด") echo "&requestStatus=$requestStatus"; if($academicYear != "ทั้งหมด") echo "&academicYear=$academicYear";?>"> หน้าแรก </a></b></div>
            <div <?php if($page <= 1) echo " style = 'visibility:hidden' "; ?> ><b ><a style=text-decoration:underline; href="?controller=checkStatus&action=index<?php if($key != "") echo "&key=$key"; if($requestType != "ทั้งหมด") echo "&requestType=$requestType"; if($requestStatus != "ทั้งหมด") echo "&requestStatus=$requestStatus"; if($academicYear != "ทั้งหมด") echo "&academicYear=$academicYear"; if($page != 2) echo "&page=".$page-1; ?>"> <i style="font-size: 18px;" class="fa fa-chevron-left"></i></a></b></div>
            <div><b> <?php echo $page; ?></b></div>
            <div <?php if($page >= $max_page) echo " style = 'visibility:hidden' "; ?> ><b><a style=text-decoration:underline; href="?controller=checkStatus&action=index<?php if($key != "") echo "&key=$key"; if($requestType != "ทั้งหมด") echo "&requestType=$requestType"; if($requestStatus != "ทั้งหมด") echo "&requestStatus=$requestStatus"; if($academicYear != "ทั้งหมด") echo "&academicYear=$academicYear"; echo "&page=".$page+1; ?>"><i style="font-size: 18px;" class="fa fa-chevron-right"></i> </a></b></div>
            <div <?php if($page >= $max_page) echo " style = 'visibility:hidden' "; ?> ><b><a style=text-decoration:underline; href="?controller=checkStatus&action=index<?php if($key != "") echo "&key=$key"; if($requestType != "ทั้งหมด") echo "&requestType=$requestType"; if($requestStatus != "ทั้งหมด") echo "&requestStatus=$requestStatus"; if($academicYear != "ทั้งหมด") echo "&academicYear=$academicYear"; echo "&page=".$max_page; ?>"> หน้าสุดท้าย </a></b></div>
        </div>
    </div>
     
</div>


<script>

    function OnChange() {
        var key = document.getElementById("key").value;
        var Request_Type = document.getElementById("Request_Type").value;
        var Request_Status = document.getElementById("Request_Status").value;
        var Academic_Year = document.getElementById("Academic_Year").value;
        var url = "?controller=checkStatus&action=index";
        if(key != "")
            url = url.concat("&key=", key);
        if(Request_Type != "ทั้งหมด")
            url = url.concat("&requestType=", Request_Type);
        if(Request_Status != "ทั้งหมด")
            url = url.concat("&requestStatus=", Request_Status);
        if(Academic_Year != "ทั้งหมด")
            url = url.concat("&academicYear=", Academic_Year);
        window.location.href = url;
    }
</script>