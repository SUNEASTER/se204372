<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    .wrapper .section .bigbox{
        margin: 5% 5%;
        margin-top: 100px;
        flex-direction: column;
        flex-wrap: wrap;
        background-color:#E5E4E2;
        border-radius: 24px;
        border: 2px solid #6f6d6d;
        display: flex;
    }

    .wrapper .section .bigbox .head{
        margin-top: 50px;
        text-align: center;
    }

    .wrapper .section .bigbox .content{
        margin-top: 30px;
        /* margin-left: 70px; */
        text-align: center;
        /* border: 2px solid #054468; */
    }

    .wrapper .section .bigbox .button1{
        margin-bottom :40px;
        margin-top : 30px;     
        display: block;
        box-sizing: border-box;
        width: 100%;
    }

    .wrapper .section .bigbox .button1 .button2{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
    }

    button{
        background-color: #ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    .wrapper .section .bigbox .button1 .button2 .success{
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .bigbox .button1 .button2 .reject{
        border-color: #f44336;
        color: red;
    }


    .wrapper .section .bigbox .button1 .button2 .success:hover{
        background-color: #04AA6D;
        color: white;
    }

    .wrapper .section .bigbox .button1 .button2 .reject:hover{
        background: #f44336;
        color: white;
    }
</style>

<div class="section">  <!-- แก้ในนี้ -->
    <form action="" method="GET">
        <div class = "bigbox">
            <div class = "content">
                <br>
                <h2 style="color:red;">การยื่นคำร้องไม่สำเร็จ</h2><br>
                <h2>เนื่องจาก : <?php echo $rejectReason; ?></h2>
                <br>
            </div>
            <input type="hidden" name="controller" value="registration"/>
            <div class="button1">
                <div class="button2">
                    <button style=" border-radius: 7px;" class="success" type="submit" name="action" value="reapply">ยื่นคำร้องใหม่</button>
                </div>                
            </div>
            <br>
        </div>
    </form>
</div>    



