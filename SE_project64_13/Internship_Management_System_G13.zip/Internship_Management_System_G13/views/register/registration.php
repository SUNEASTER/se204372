<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    .wrapper .section .bigbox{
        margin: 5% 5%;
        margin-top: 100px;
        flex-direction: column;
        flex-wrap: wrap;
        background-color:#e9f0f7;
        border-radius: 24px;
        border: 2px solid #054468;
        display: flex;
    }


    .wrapper .section .bigbox .head{
        margin-top: 50px;
        text-align: center;
    }

    .wrapper .section .bigbox .content{
        margin-top: 30px;
        margin-left: 70px;
    }

    .wrapper .section .bigbox .button1{
        margin-bottom :40px;
        margin-top : 30px;     
        display: block;
        box-sizing: border-box;
        width: 100%;
    }

    .wrapper .section .bigbox .button1 .button2{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        
    }

    button{
        background-color: #ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    .wrapper .section .bigbox .button1 .button2 .success{
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .bigbox .button1 .button2 .reject{
        border-color: #f44336;
        color: red;
    }


    .wrapper .section .bigbox .button1 .button2 .success:hover{
        background-color: #04AA6D;
        color: white;
    }

    .wrapper .section .bigbox .button1 .button2 .reject:hover{
        background: #f44336;
        color: white;
    }

    .wrapper .section .table{
        text-align: center;
        font-size: 26px;
        margin-bottom: 30px;
        color:  #b31f1c;
    }

    .wrapper .section .contentH{
        background: rgb(5, 68, 104);
        color: rgb(206, 240, 253);
        font-size: 16px;
        text-align: center;
    }

    /* หัวข้อในการกรอกข้อมูล */
    .wrapper .section .contentHP{
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
        /* ขยับ */
        margin-left: 100px;
    }

    /* -ข้อความ */
    .wrapper .section .content{
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
            /* ขยับ */
            margin-left: 127px;
    }

    .wrapper .section .contentDB{
        font-size: 20px;
        color: black;
        text-align: start;
            /* ขยับ */
        margin-left: 50px;
    }

        /* new */
    /* สเตตัส ของผู้ป่วย สร้างเพิ่มได้ b1 b2 b3 ......*/
    /* เขียว */
    .wrapper .section .content .b1{
        color: green;
    }

    /* แดง */    
    .wrapper .section .content .b2{
        color: red;
    }

    /* รายละเอียดเพิ่มเติม */
    .wrapper .section .content .d{
        color: rgb(7, 105, 185);
        text-decoration: underline;
    }

    /* 2. กล่องกลาง */
    .wrapper .section .flexbox{
        display: flex;
        box-sizing: border-box;
        flex-direction: column;
        justify-content: space-evenly;
        flex-wrap: wrap;
        border: 2px solid #6f6d6d; 
        margin-bottom: 15px;
        padding: 20px 20px 20px 20px;
        border-radius: 24px;
        background-color:#E5E4E2;
        
       
    }
    
    

    /* 3.กล่องใหญ่ */
    .wrapper .section .flexbox2{
        margin: 5% 5%;
        margin-top: 50px;
        flex-direction: column;
        flex-wrap: wrap;
        /* border: 2px solid black; */
    }

    /* กล่องเล็ก */
    .wrapper .section .box{
        display: block;
        box-sizing: border-box;
        width: 100%;
        /* border: 3px solid black; */
    }

    /* เเจ้งเตือนไม่กรอกข้อมูล */
    .wrapper .section .box .warning{
        color: red;
        text-align: center;
    }

    /* ทำ กล่องเล็กสุด เป็นกล่องเล็ก */
    .wrapper .section .flexbox-in{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }
    .wrapper .section .box-in  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 50%;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .wrapper .section .box-iny  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 100%;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    /* กล่องเล็กสุด 2 กล่อง (อนุมัติไม่-อนุมัติ) */
    .wrapper .section .flexbox-inx{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        /* border: 3px solid black; */
    }

    .wrapper .section .box-inx  {
        display: block;
        box-sizing: border-box;
        justify-content: center;
        /* border: 3px solid black; */
    }

    button{
        background-color: #ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    /* Green */
    .wrapper .section .success {
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .success:hover {
        background-color: #04AA6D;
        color: white;
    }

    /* Red */
    .wrapper .section .reject {
        border-color: #f44336;
        color: red;
    }

    .wrapper .section .reject:hover {
        background: #f44336;
        color: white;
    }

</style>

<div class="section">  <!-- แก้ในนี้ -->
    <form action="" method="GET">
        <div class = "flexbox2">
            <div class="flexbox">
                <div class="box">
                    <div class="table">
                        <b> ใบคำร้องขอฝึกงาน/สหกิจศึกษาในสถานประกอบการ </b>
                    </div>
                </div>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลใบคำร้อง</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>รูปแบบใบคำร้อง :</b>
                                <input style="margin-left: 15px;"type="radio" id="chk1" name="type" value="ฝึกงาน">
                                <b>ฝึกงาน</b>
                                <input style="margin-left: 15px;"type="radio" id="chk2" name="type" value="สหกิจศึกษา">
                                <b>สหกิจศึกษา </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>ปีการศึกษาที่ยื่น : <?php echo $year; ?></</b>
                            </div>
                        </div>
                    </div>
                </div>

                <br>

                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลนิสิต</b>
                    </div>
                </div>

                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>ชื่อ-นามสกุล : <?php echo $user->FirstName." ".$user->LastName; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>เพศ :  <?php echo $user->Gender; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>รหัสนิสิต :  <?php echo $user->Student_Id; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>ชั้นปี : <?php echo $user->Student_Year; ?> </b>
                            </div> 
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>คณะ : <?php echo $user->Student_Faculty; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style= visibility:hidden;>* </b><b>สาขา : <?php echo $user->Student_Branch; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>เบอร์โทร</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="studentPhone" id="studentPhone" placeholder=" เบอร์โทร ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ชื่อ Facebook </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="nameFB" id="nameFB" placeholder=" ชื่อ Facebook ..."/> 
                            </div>
                        </div>
                    </div>
                </div>

                <br>

                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลการฝึกงาน/สหกิจศึกษา</b>
                    </div>
                </div>

                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ตำแหน่งที่ไปฝึกงาน</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="jobTitle" id="jobTitle" placeholder=" ตำแหน่งที่ไปฝึกงาน ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <!--  -->
                        </div>
                        <div class="box-iny">
                            <div class="content">
                                <b style=color:red;>* </b><b>ค่าตอบแทน :</b>
                                <input style="margin-left: 15px;"type="radio" id="haveMoney" name="com" value="มี" onchange="payOnChange(this.value)">
                                <b>มี</b>
                                <div style="display: none; margin:0px 0px 0px 17px; width: 20%; height: 28px;" id="payChk">
                                    <input style=" width: 45%; height: 28px;" type="text" name="money" id="money" placeholder=" ค่าตอบแทน ..."/> 
                                    <b>บาท/วัน</b>
                                </div>
                                <input style="margin-left: 17px;"type="radio" id="noMoney" name="com" value="ไม่มี" onchange="payOnChange(this.value)">
                                <b>ไม่มี</b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ที่พัก :</b>
                                <input style="margin-left: 15px;"type="radio" id="yes" name="hotel" value="มี">
                                <b>มี</b>
                                <input style="margin-left: 15px;"type="radio" id="no" name="hotel" value="ไม่มี">
                                <b>ไม่มี</b>
                            </div>
                        </div>
                        <div class="box">
                            <div class="content">
                                <b style=color:red;>* </b><b>ระยะเวลาการฝึกงาน/สหกิจศึกษาตั้งแต่วันที่</b>
                                <input style="margin-left: 7px; margin-right: 7px;" type="date" name="dateStart" id="dateStart" class="form-control form-control-lg" value=" "/>
                                <b>ถึง</b>
                                <input style="margin-left: 7px;" type="date" name="dateEnd" id="dateEnd" class="form-control form-control-lg" value=" "/>
                            </div>
                        </div>
                    </div>
                </div>

                <br>
                
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลผู้รับหนังสือขอความอนุเคราะห์</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ชื่อ </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="FnameRecipient" id="FnameRecipient" placeholder=" ชื่อ ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>นามสกุล </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="LnameRecipient" id="LnameRecipient" placeholder=" นามสกุล ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ตำแหน่ง </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="recipientPosition" id="recipientPosition" placeholder=" ตำแหน่ง ..."/> 
                            </div>
                        </div>
                    </div>
                </div>
                <br>

                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลผู้ประสานงาน</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>ชื่อ</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="FnameCoordinator" id="FnameCoordinator" placeholder=" ชื่อ ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>นามสกุล</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="LnameCoordinator" id="LnameCoordinator" placeholder=" นามสกุล ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>เบอร์โทร</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="coordinatorPhone" id="coordinatorPhone" placeholder=" เบอร์โทร ..."/> 
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b style=color:red;>* </b><b>อีเมล</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="coordinatorEmail" id="coordinatorEmail" placeholder=" อีเมล ..."/> 
                            </div>
                        </div>
                    </div>
                </div>

                <br>

                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลที่อยู่สถานประกอบการ</b>
                    </div>
                </div>

                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content" id="chkcompany0">
                                <b style=color:red;>* </b><b>สถานประกอบการ</b><br>
                                <select style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" name="company_id" class="form-select" id="company">
                                    <?php echo "<option hidden='hidden' value=0>กรุณาเลือกสถานประกอบการ</option>";
                                        foreach($company_list as $company){
                                            echo "<option value=$company->Company_Id>$company->Name</option>";}?>
                                        }?>
                                </select>
                            </div>
                        </div>
                        <div class="box-in">
                            <!--  -->
                        </div>

                        <div class="box-in" style="display: none;" id="chkcompany1">
                            <div class="content">
                                <b style=color:red;>* </b><b>ชื่อสถานประกอบการ</b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="nameCompany" id="nameCompany" placeholder=" ชื่อสถานประกอบการ ..."/> 
                            </div>
                        </div>
                        <div class="box-in" style="display: none;" id="chkcompany2">
                            <div class="content">
                                <b style=color:red;>* </b><b>สถานที่ตั้งเลขที่ </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="numAddress" id="numAddress" placeholder=" เลขที่อยู่ ...."/> 
                            </div>
                        </div>
                        <div class="box-in" style="display: none;" id="chkcompany3">
                            <div class="content">
                                <b style=color:red;>* </b><b>ถนน </b><br>
                                <input style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" type="text" name="street" id="street" placeholder=" ถนน ..."/> 
                            </div>
                        </div>
                        <div class="box-in" style="display: none;" id="chkcompany4">
                            <div class="content">
                                <b style=color:red;>* </b><b>จังหวัด </b><br>
                                <select style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" name="province_id" class="form-select" id="Province" onchange="provinceOnChange(this.value)">
                                    <?php echo "<option hidden='hidden' value=0>เลือกจังหวัด</option>";
                                        foreach($Province_list as $Province){
                                            echo "<option value=$Province->Province_Id>$Province->Province_NameTH</option>";}?>
                                        }?>
                                </select>
                            </div>
                        </div>
                        <div class="box-in" style="display: none;" id="chkcompany5">
                            <div class="content">
                            <b style=color:red;>* </b><b>อำเภอ/เขต </b><br>
                                <select style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" name="amphure_id" class="form-select" id="Amphure" onchange="amphureOnChange(this.value)">
                                    <option hidden='hidden' value=0>กรุณาเลือกจังหวัดก่อน</option>
                                </select>
                            </div>
                        </div>
                        <div class="box-in" style="display: none;" id="chkcompany6">
                            <div class="content">
                                <b style=color:red;>* </b><b>ตำบล/แขวง</b><br>
                                <select style="margin:0px 0px 0px 17px; width: 55%; height: 28px;" name="district_id" class="form-select" id="District">
                                        <option hidden='hidden' value=0>กรุณาเลือกอำเภอก่อน</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="box-in">
                            <div class="content">
                                <input style="margin-left: 15px;"type="checkbox" id="newCompany" name="newCompany" value="ใช่" onclick="newCompanyOnChange()"><b> ต้องการเสนอสถานประกอบการ</b>
                            </div>
                        </div>

                <br><br>

                <div class="box">
                    <div class="flexbox-inx">
                        <input type="hidden" name="controller" value="registration"/> 
                        <button style=" border-radius: 7px;"class="success" type="submit" name="action" value="register" onclick="validate()">ยื่นคำร้อง </button>
                    </div>
                </div>

            </div>
        </div>
    </form>
</div>   
<script>
    function provinceOnChange(id) {
        const xhttp1 = new XMLHttpRequest();
        xhttp1.onload = function() {
            document.getElementById("Amphure").innerHTML =this.responseText;
        }
        xhttp1.open("GET", "provinceOnChange.php?Province_Id="+id);
        xhttp1.send();
        const xhttp2 = new XMLHttpRequest();
        xhttp2.onload = function() {
            document.getElementById("District").innerHTML =this.responseText;
        }
        xhttp2.open("GET", "amphureOnChange.php?Amphure_Id=0");
        xhttp2.send();
    }
    function amphureOnChange(id) {
        const xhttp = new XMLHttpRequest();
        xhttp.onload = function() {
            document.getElementById("District").innerHTML =this.responseText;
        }
        xhttp.open("GET", "amphureOnChange.php?Amphure_Id="+id);
        xhttp.send();
    }

    function payOnChange(chk) {
        if(chk == "มี") {
            document.getElementById("payChk").style.display = "inline-block";
        } else {
            document.getElementById("payChk").style.display = "none"
        }
    }

    function newCompanyOnChange() {
        var checkBox = document.getElementById("newCompany");
        if(checkBox.checked) {
            document.getElementById("chkcompany0").style.display = "none";
            document.getElementById("chkcompany1").style.display = "block";
            document.getElementById("chkcompany2").style.display = "block";
            document.getElementById("chkcompany3").style.display = "block";
            document.getElementById("chkcompany4").style.display = "block";
            document.getElementById("chkcompany5").style.display = "block";
            document.getElementById("chkcompany6").style.display = "block";
        } else {
            document.getElementById("chkcompany0").style.display = "block";
            document.getElementById("chkcompany1").style.display = "none"
            document.getElementById("chkcompany2").style.display = "none"
            document.getElementById("chkcompany3").style.display = "none"
            document.getElementById("chkcompany4").style.display = "none"
            document.getElementById("chkcompany5").style.display = "none"
            document.getElementById("chkcompany6").style.display = "none"
        }
    }
    
    function validate() {
        var chk1 = document.getElementById("chk1");
        chk1.setCustomValidity('');
        var chk2 = document.getElementById("chk2");
        chk2.setCustomValidity('');
        var studentPhone = document.getElementById("studentPhone");
        studentPhone.value = studentPhone.value.trim();
        studentPhone.setCustomValidity('');
        var nameFB = document.getElementById("nameFB");
        nameFB.value = nameFB.value.trim();
        nameFB.setCustomValidity('');
        var jobTitle = document.getElementById("jobTitle");
        jobTitle.value = jobTitle.value.trim();
        jobTitle.setCustomValidity('');
        var haveMoney = document.getElementById("haveMoney");
        haveMoney.setCustomValidity('');
        var money = document.getElementById("money");
        money.value = money.value.trim();
        money.setCustomValidity('');
        var noMoney = document.getElementById("noMoney");
        noMoney.setCustomValidity('');
        var yes = document.getElementById("yes");
        yes.setCustomValidity('');
        var no = document.getElementById("no");
        no.setCustomValidity('');
        var dateStart = document.getElementById("dateStart");
        dateStart.setCustomValidity('');
        var dateEnd = document.getElementById("dateEnd");
        dateEnd.setCustomValidity('');
        var FnameRecipient = document.getElementById("FnameRecipient");
        FnameRecipient.value = FnameRecipient.value.trim();
        FnameRecipient.setCustomValidity('');
        var LnameRecipient = document.getElementById("LnameRecipient");
        LnameRecipient.value = LnameRecipient.value.trim();
        LnameRecipient.setCustomValidity('');
        var recipientPosition = document.getElementById("recipientPosition");
        recipientPosition.value = recipientPosition.value.trim();
        recipientPosition.setCustomValidity('');
        var FnameCoordinator = document.getElementById("FnameCoordinator");
        FnameCoordinator.value = FnameCoordinator.value.trim();
        FnameCoordinator.setCustomValidity('');
        var LnameCoordinator = document.getElementById("LnameCoordinator");
        LnameCoordinator.value = LnameCoordinator.value.trim();
        LnameCoordinator.setCustomValidity('');
        var coordinatorPhone = document.getElementById("coordinatorPhone");
        coordinatorPhone.value = coordinatorPhone.value.trim();
        coordinatorPhone.setCustomValidity('');
        var coordinatorEmail = document.getElementById("coordinatorEmail");
        coordinatorEmail.value = coordinatorEmail.value.trim();
        coordinatorEmail.setCustomValidity('');
        var newCompany = document.getElementById("newCompany");
        var company = document.getElementById("company");
        company.setCustomValidity('');
        var nameCompany = document.getElementById("nameCompany");
        nameCompany.value = nameCompany.value.trim();
        nameCompany.setCustomValidity('');
        var numAddress = document.getElementById("numAddress");
        numAddress.value = numAddress.value.trim();
        numAddress.setCustomValidity('');
        var street = document.getElementById("street");
        street.value = street.value.trim();
        street.setCustomValidity('');
        var Province = document.getElementById("Province");
        Province.setCustomValidity('');
        var Amphure = document.getElementById("Amphure");
        Amphure.setCustomValidity('');
        var District = document.getElementById("District");
        District.setCustomValidity('');
        var dateStartCal = new Date(dateStart.value);
        dateStartCal.setHours(0,0,0,0);
        var dateEndCal = new Date(dateEnd.value);
        dateEndCal.setHours(0,0,0,0);
        var today = new Date();
        today.setHours(0,0,0,0);

        if(!(chk1.checked || chk2.checked) ){
            chk1.setCustomValidity('กรุณาเลือกรูปแบบการฝึกงาน');
        }
        else if(studentPhone.value.length != 10 || !Number.isInteger(Number(studentPhone.value))) {
            studentPhone.setCustomValidity('เบอร์โทรนิสิตต้องเป็นตัวเลข 10 หลัก');
        }
        else if(nameFB.value == "") {
            nameFB.setCustomValidity('กรุณาใส่ชื่อ Facebook');
        }
        else if(jobTitle.value == "") {
            jobTitle.setCustomValidity('กรุณาใส่ตำแหน่งที่ไปฝึกงาน');
        }
        else if(!(haveMoney.checked || noMoney.checked) ){
            haveMoney.setCustomValidity('กรุณาเลือกว่ามีค่าตอบแทนหรือไม่');
        }
        else if(haveMoney.checked && money.value == ""){
            money.setCustomValidity('กรุณาใส่ค่าตอบแทน');
        }
        else if(haveMoney.checked && !Number.isInteger(Number(money.value))){
            money.setCustomValidity('กรุณาใส่ค่าตอบแทนเป็นตัวเลข');
        }
        else if(haveMoney.checked && money.value <= 0){
            money.setCustomValidity('ค่าตอบแทนต้องมากกว่า0');
        }
        if(!(yes.checked || no.checked) ){
            yes.setCustomValidity('กรุณาเลือกว่ามีที่พักหรือไม่');
        }
        else if(dateStart.value == "") {
            dateStart.setCustomValidity('กรุณาเลือกวันฝึกงานวันแรก');
        }
        else if(dateEnd.value == "") {
            dateEnd.setCustomValidity('กรุณาเลือกวันฝึกงานวันสุดท้าย');
        }
        else if(dateStartCal-today < 0) {
            dateStart.setCustomValidity('ไม่สามารถเลือกวันฝึกงานวันแรกเป็นวันอดีตได้');
        }
        else if(dateStartCal-today == 0) {
            dateStart.setCustomValidity('ไม่สามารถเลือกวันฝึกงานวันแรกเป็นวันนี้ได้');
        }
        else if(dateEndCal-dateStartCal < 0) {
            dateEnd.setCustomValidity('ไม่สามารถเลือกวันฝึกงานวันสุดท้ายเป็นก่อนวันฝึกงานวันแรกได้');
        }
        else if(dateEndCal-dateStartCal < 2505600000) {
            dateEnd.setCustomValidity('ต้องฝึกงานอย่างน้อย 30 วัน');
        }
        else if(FnameRecipient.value == "") {
            FnameRecipient.setCustomValidity('กรุณาใส่ชื่อผู้รับหนังสือขอความอนุเคราะห์');
        }
        else if(LnameRecipient.value == "") {
            LnameRecipient.setCustomValidity('กรุณาใส่นามสกุลผู้รับหนังสือขอความอนุเคราะห์');
        }
        else if(recipientPosition.value == "") {
            recipientPosition.setCustomValidity('กรุณาใส่ตำแหน่งผู้รับหนังสือขอความอนุเคราะห์');
        }
        else if(FnameCoordinator.value == "") {
            FnameCoordinator.setCustomValidity('กรุณาใส่ชื่อผู้ประสานงาน');
        }
        else if(LnameCoordinator.value == "") {
            LnameCoordinator.setCustomValidity('กรุณาใส่นามสกุลผู้ประสานงาน');
        }
        else if(coordinatorPhone.value.length != 10 || !Number.isInteger(Number(coordinatorPhone.value))) {
            coordinatorPhone.setCustomValidity('เบอร์โทรผู้ประสานงานต้องเป็นตัวเลข 10 หลัก');
        }
        else if(coordinatorEmail.value == "") {
            coordinatorEmail.setCustomValidity('กรุณาใส่อีเมลผู้ประสานงาน');
        }
        else if(newCompany.checked) {
            if(nameCompany.value == ""){
                nameCompany.setCustomValidity('กรุณาใส่ชื่อสถานประกอบการ');
            }
            else if(numAddress.value == ""){
                numAddress.setCustomValidity('กรุณาใส่เลขที่อยู่');
            }
            else if(street.value == ""){
                street.setCustomValidity('กรุณาใส่ถนน');
            }
            else if(Province.value == "0"){
                Province.setCustomValidity('กรุณาเลือกจังหวัด');
            }
            else if(Amphure.value == "0"){
                Amphure.setCustomValidity('กรุณาเลือกอำเภอ');
            }
            else if(District.value == "0"){
                District.setCustomValidity('กรุณาเลือกตำบล');
            }
        }
        else if(company.value == "0"){
            company.setCustomValidity('กรุณาเลือกสถานประกอบการ');
        }
    }
</script>

