<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  <!--chart-->
<title> หน้าหลัก </title>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    /* กล่องใหญ่ */
    .flexbox2{
        margin: 5% 5%;
        margin-top: 5px;
        flex-direction: row;
        flex-wrap: wrap;
    }

    .flexbox{
        display: flex;
        box-sizing: border-box;
        flex-direction: column;
        justify-content: space-evenly;
        flex-wrap: wrap;
        /* border: 2px solid #054468;  */
        margin-bottom: 15px;
        padding: 0px 20px 20px 20px;
        border-radius: 24px;
        transition: 0.4s;
    }
    
    /* กล่องเล็ก */
    .box{
        display: block;
        box-sizing: border-box;
        width: 100%;
        /* border: 3px solid black; */
        margin-top: 50px;
    }

    .flexbox-in{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }

    .box-in  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 50%;
    }

    .imgx{
        width: 100%;
        object-fit: cover;
        border-radius: 30px;
        border: 4px solid black;
    }

    .imgx:hover{
        border: 7px solid #6f6d6d ;
    }

</style>

<div class="section">  <!-- แก้ในนี้ -->
    <div class="container bg">
        <div class="flexbox2">
            <div class="flexbox">
                <div class="flexbox">
                    <div class="box">
                        <img class="imgx" src="/resources/1.png" alt="1">
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div> 

