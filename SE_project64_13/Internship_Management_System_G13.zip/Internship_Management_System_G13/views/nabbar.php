<title>ฝึกงาน/สหกิจศึกษา</title>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
        @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    *{
        list-style: none;
        text-decoration: none;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Open Sans','Prompt', sans-serif;
    }

    body{
        background: #ffffff;
    }

    .wrapper .sidebar{
        background: #b31f1c;
        position: fixed;
        top: 0;
        left: 0;
        width: 300px;
        height: 100%;
        padding: 20px 0;
        transition: all 0.5s ease;
    }

    .wrapper .sidebar .profile{
        margin-bottom: 30px;
        text-align: center;
    }
    .wrapper .sidebar .profile img{
    display: block;
    width: 100%;
    margin: 0 auto;
    text-align: center;
 
}

    .wrapper .sidebar .profile h3{
        color: #ffffff;
        margin: 10px 0 5px;
    }

    .wrapper .sidebar ul li a{
        display: block;
        padding: 13px 30px;
        /* border-bottom: 1px ; */
        color: rgb(241, 237, 237);
        font-size: 16px;
        position: relative;
    }

    .wrapper .sidebar ul li a .icon{
        color: #dee4ec;
        width: 30px;
        display: inline-block;
    }
    .wrapper .sidebar ul li a:hover,
    .wrapper .sidebar ul li a.active{
        color: black;

        background:white;
        border-right: 2px solid red;
    }

    .wrapper .sidebar ul li a:hover .icon,
    .wrapper .sidebar ul li a.active .icon{
        color: black;
    }

    .wrapper .sidebar ul li a:hover:before,
    .wrapper .sidebar ul li a.active:before{
        display: block;
    }
    .wrapper .section{
    width: calc(100% - 300px);
    margin-left: 300px;
    transition: all 0.5s ease;
}

.wrapper .section .top_navbar{
    background: #E5E4E2;
    height: 50px;
    flex-direction: row;
    display: flex;
    align-items: center;
    justify-content: flex-end;  
    padding: 0 20px;

}

.wrapper .section .top_navbar .hamburger .item1{
    font-size: 20px;
    padding-right: 30px;
    color: black;
}

.wrapper .section .top_navbar .hamburger a{
    font-size: 28px;
    color: black;
}

.wrapper .section .top_navbar .hamburger a:hover{
    color: #C21807;
}

body.active .wrapper .sidebar{
    left: -300px;
}

body.active .wrapper .section{
    margin-left: 0;
    width: 100%;
}

</style>
    
</head>
<body>
    

<div class="wrapper">
    <!--Top menu -->
    <div class="section"> 
        <div class="top_navbar">
            <div class="hamburger" <?php if(!isset($_SESSION['openID'])) echo " style='display: none';";?>>
                <span class="item1"> คุณ <?php echo $user->FirstName." ".$user->LastName." ";?> </span>
                <a href="?controller=login&action=logout">
                    <i class="fa fa-power-off"></i>
                    <span class="item">ออกจากระบบ</span>
                </a>
            </div>
            <div class="hamburger" <?php if(isset($_SESSION['openID'])) echo " style='display: none';";?>>
                <a href="?controller=login&action=loginForm">
                    <i class="fas fa-user-circle"></i>
                    <span class="item">เข้าสู่ระบบ</span>
                </a>
            </div>
        </div>

    </div>
    

    <div class="sidebar">
        <div class="profile">
        <img src="../resources/LOGOSE.png" alt="SE">
            
        </div>
        <ul>
            <li>
                <a href="?controller=home&action=index"<?php if(!isset($_GET['controller']) || $_GET['controller']=="home") echo "class=active"?>>
                    <span class="icon"><i style="font-size: 18px;" class="fas fa-home"></i></span>
                    <span class="item">หน้าหลัก</span>
                </a>
            </li>

            <li <?php if(!isset($_SESSION["role"]) || $_SESSION["role"] != "Student") echo " style='display: none';";?>>
                <a href="?controller=registration&action=index"<?php if(isset($_GET['controller'])) if($_GET['controller']=="registration") echo "class=active"?>>
                    <span class="icon"><i style="font-size: 18px;" class="fa fa-edit"></i></span>
                    <span class="item">ยื่นคำร้องฝึกงาน/สหกิจศึกษา</span>
                </a>
            </li>

            <li <?php if(!isset($_SESSION["role"]) || $_SESSION["role"] != "Teacher") echo " style='display: none';";?>>
                <a href="?controller=checkRG&action=index"<?php if(isset($_GET['controller'])) if($_GET['controller']=="checkRG") echo "class=active"?>>
                    <span class="icon"><i style="font-size: 18px;" class="fa fa-user-plus"></i></span>
                    <span class="item">ตรวจสอบคำร้องนิสิต</span>
                </a>
            </li>

            <li <?php if(!isset($_SESSION["role"]) || $_SESSION["role"] != "Student") echo " style='display: none';";?>>
                <a href="?controller=checkStatus&action=index"<?php if(isset($_GET['controller'])) if($_GET['controller']=="checkStatus") echo "class=active"?>>
                    <span class="icon"><i style="font-size: 18px;" class="material-icons">assignment_turned_in</i></span>
                    <span class="item">ตรวจสอบสถานะการยื่นคำร้อง</span>
                </a>
            </li>

            <li <?php if(!isset($_SESSION["role"]) || $_SESSION["role"] == "Student") echo " style='display: none';";?>>
                <a href="?controller=checkStudent&action=index"<?php if(isset($_GET['controller'])) if($_GET['controller']=="checkStudent") echo "class=active"?>>
                    <span class="icon"><i style="font-size: 20px;" class="material-icons">assignment</i></span>
                    <span class="item">ประวัติการยื่นคำร้อง</span>
                </a>
            </li>

        </ul>
    </div>