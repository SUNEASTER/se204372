<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');
    
    .wrapper .section .table{
        text-align: center;
        font-size: 26px;
        margin-bottom: 30px;
        color: #b31f1c;
    }

    .wrapper .section .table h1{
        margin-top: 60px;
    }

    /* -ข้อความ */
    .wrapper .section .content{
        
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
        margin-left: 17px;
        margin-right: 70px;
    }

    .wrapper .section .contentx{
        font-size: 20px;
        color: black;
        text-align: right;
        flex-direction: row;
    }

    /* สเตตัส ของผู้ป่วย สร้างเพิ่มได้ b1 b2 b3 ......*/
    /* เขียว */
    .wrapper .section .content .b1{
        color: green;
    }

    /* แดง */    
    .wrapper .section .content .b2{
        color: red;
    }

    /* รายละเอียดเพิ่มเติม */
    .wrapper .section .contentx .d{
        color: rgb(7, 105, 185);
        text-decoration: underline;
    }

    /* 2. กล่องกลาง */
    .wrapper .section .flexbox{
        display: flex;
        box-sizing: border-box;
        flex-direction: column;
        justify-content: space-evenly;
        flex-wrap: wrap;
        border: 2px solid #6f6d6d; 
        margin-bottom: 15px;
        padding: 20px 20px 20px 20px;
        border-radius: 24px;
        background-color:#E5E4E2;
    }

    /* 3.กล่องใหญ่ */
    .wrapper .section .flexbox2{
        margin: 5% 5%;
        margin-top: 50px;
        flex-direction: column;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }

    /* กล่องเล็ก */
    .wrapper .section .box{
        display: block;
        box-sizing: border-box;
        width: 100%;
        /* border: 3px solid black; */
    }

    /* ทำ กล่องเล็กสุด เป็นกล่องเล็ก */
    .wrapper .section .flexbox-in{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }
    .wrapper .section .box-in  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 50%;
    }

    /* กล่องเล็กสุด 2 กล่อง (อนุมัติไม่-อนุมัติ) */
    .wrapper .section .flexbox-inx{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        /* border: 3px solid black; */
    }

    .wrapper .section .box-inx  {
        display: block;
        box-sizing: border-box;
        justify-content: center;
        /* border: 3px solid black; */
    }

    button{
        background-color:#ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    /* Green */
    .wrapper .section .success {
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .success:hover {
        background-color: #04AA6D;
        color: white;
    }

    /* Red */
    .wrapper .section .reject {
        border-color: #f44336;
        color: red;
    }

    .wrapper .section .reject:hover {
        background: #f44336;
        color: white;
    }

</style>

<div class="section">  <!-- แก้ในนี้ -->
    <div class="flexbox2">
        <form action="" method="GET">
            <input type="hidden" name="controller" value="checkRG"/>
            <div class="flexbox">
                <div class="box">
                    <div class="table">
                        <b> ยืนยันการไม่อนุมัติ </b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">
                        <div class="box-in">
                            <div class="content">
                                <b> รูปแบบใบคำร้อง : </b>
                                <b <?php if($requestForm->Request_Type == "ฝึกงาน"){
                                    echo " style = 'color:  #723C2A'";
                                }
                                else if($requestForm->Request_Type == "สหกิจศึกษา"){
                                    echo " style = 'color: #191970'";
                                }
                                ?>><?php echo $requestForm->Request_Type; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <!--  -->
                        </div>
                    </div>
                </div>
                <div class="box">
                    <div class="content">
                        <b>ปีการศึกษาที่ยื่น : <?php echo $requestForm->Academic_Year; ?></b>
                    </div>
                </div>
                <br>
                <div class="box">
                    <div class="content">
                        <b>รหัสนิสิต : <?php echo $requestForm->Requester->Student_Id; ?></b>
                    </div>
                </div>
                <div class="box">
                    <div class="content">
                        <b>ชื่อ-นามสกุล : <?php echo $requestForm->Requester->FirstName." ".$requestForm->Requester->LastName; ?></b>
                    </div> 
                </div>
                <div class="box">
                    <div class="content">
                        <b>สถานประกอบการ : <?php echo $requestForm->Company->Name; ?> </b>
                    </div>
                </div>
                <br>
                <div class="box">
                    <div class="content">
                        <b>วันที่ยื่นคำร้อง : <?php echo date_format(date_create($requestForm->CreateDate),"d/m/Y")?></b>
                    </div>
                </div>
                <br>
                <div class="box">   
                    <div class="content">
                        <b>เหตุผลการไม่อนุมัติ : </b>
                            <select style="margin:0px 0px 0px 17px; width: 25%; height: 28px;" name="Reason_id" class="form-select" id="Reason" onchange="onChange()">
                                <option hidden='hidden' value=เลือกเหตุผล>เลือกเหตุผล</option>
                                <option value="ตำแหน่งไม่สอดคล้องกับหลักสูตรที่เรียน">ตำแหน่งไม่สอดคล้องกับหลักสูตรที่เรียน</option>
                                <option value="เงื่อนไขการฝึกงาน/สหกิจศึกษาไม่ผ่าน">เงื่อนไขการฝึกงาน/สหกิจศึกษาไม่ผ่าน</option>
                                <option value="อื่นๆ">อื่นๆ</option>
                                <!-- เพิ่มตัวเลือก -->
                            </select>
                    </div>
                </div>
                <div class="box">   
                    <div class="content" style="display: none;" id="hidecontent">
                        <b>เหตุผลอื่นๆ :</b> <input type="text" name="other" id="other" placeholder="ใส่เหตุผล">
                    </div>
                </div>
                <br><br>
                <div class="box">
                    <div class="flexbox-inx">
                        <button style=" border-radius: 7px;" class="success" type="submit" name="action" onclick="validate(this.value)" value="disapprove" >ตกลง</button>
                        <button style=" border-radius: 7px;" class="reject" type="submit" name="action" onclick="validate(this.value)" value="index">ยกเลิก</button>
                    </div>
                </div>
            </div>   
            <input type="hidden" name="requestFormID" value="<?php echo $requestForm->Request_Id; ?>"/>
        </form>
    </div>
</div>

<script>
    function onChange() {
        var reason = document.getElementById("Reason").value;
        
        if(reason == "อื่นๆ") {
            document.getElementById("hidecontent").style.display = "block";
        } else {
            document.getElementById("hidecontent").style.display = "none"
        }
    }

    function validate(action) {
        var Reason = document.getElementById("Reason");
        Reason.setCustomValidity('');
        var other = document.getElementById("other");
        other.value = other.value.trim();
        other.setCustomValidity('');
        if(action == 'disapprove'){
            if(Reason.value == "เลือกเหตุผล") {
            Reason.setCustomValidity('กรุณาเลือกเหตุผล');
            }
            else if(Reason.value == "อื่นๆ" && other.value == ""){
                other.setCustomValidity('กรุณาใส่เหตุผล');
            }
        }
    }
</script>

