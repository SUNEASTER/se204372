<style>
    @import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');
    @import url('https://fonts.googleapis.com/css?family=Kanit%7CPrompt');

    .wrapper .section .bigbox{
        margin: 5% 5%;
        margin-top: 100px;
        flex-direction: column;
        flex-wrap: wrap;
        background-color:#e9f0f7;
        border-radius: 24px;
        border: 2px solid #054468;
        display: flex;
    }


    .wrapper .section .bigbox .head{
        margin-top: 50px;
        text-align: center;
    }

    .wrapper .section .bigbox .content{
        margin-top: 30px;
        margin-left: 70px;
    }

    .wrapper .section .bigbox .button1{
        margin-bottom :40px;
        margin-top : 30px;     
        display: block;
        box-sizing: border-box;
        width: 100%;
    }

    .wrapper .section .bigbox .button1 .button2{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        
    }

    button{
        background-color: #ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    .wrapper .section .bigbox .button1 .button2 .success{
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .bigbox .button1 .button2 .reject{
        border-color: #f44336;
        color: red;
    }


    .wrapper .section .bigbox .button1 .button2 .success:hover{
        background-color: #04AA6D;
        color: white;
    }

    .wrapper .section .bigbox .button1 .button2 .reject:hover{
        background: #f44336;
        color: white;
    }

    .wrapper .section .table{
        text-align: center;
        font-size: 26px;
        margin-bottom: 30px;
        color: #b31f1c;
    }

    .wrapper .section .contentH{
        background: rgb(5, 68, 104);
        color: rgb(206, 240, 253);
        font-size: 16px;
        text-align: center;
    }

    /* หัวข้อในการกรอกข้อมูล */
    .wrapper .section .contentHP{
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
        /* ขยับ */
        margin-left: 100px;
    }

    /* -ข้อความ */
    .wrapper .section .content{
        font-size: 20px;
        color: black;
        text-align: start;
        flex-direction: row;
            /* ขยับ */
        margin-left: 127px;
        margin-right: 70px;
        word-wrap: break-word;
    }

    .wrapper .section .contentDB{
        font-size: 20px;
        color: black;
        text-align: start;
            /* ขยับ */
        margin-left: 50px;
    }

        /* new */
    /* สเตตัส ของผู้ป่วย สร้างเพิ่มได้ b1 b2 b3 ......*/
    /* เขียว */
    .wrapper .section .content .b1{
        color: green;
    }

    /* แดง */    
    .wrapper .section .content .b2{
        color: red;
    }

    /* รายละเอียดเพิ่มเติม */
    .wrapper .section .content .d{
        color: rgb(7, 105, 185);
        text-decoration: underline;
    }

    /* 2. กล่องกลาง */
    .wrapper .section .flexbox{
        display: flex;
        box-sizing: border-box;
        flex-direction: column;
        justify-content: space-evenly;
        flex-wrap: wrap;
        border: 2px solid #6f6d6d; 
        margin-bottom: 15px;
        padding: 20px 20px 20px 20px;
        border-radius: 24px;
        background-color:#E5E4E2;
    }

    /* 3.กล่องใหญ่ */
    .wrapper .section .flexbox2{
        margin: 5% 5%;
        margin-top: 50px;
        flex-direction: column;
        flex-wrap: wrap;
        /* border: 2px solid black; */
    }

    /* กล่องเล็ก */
    .wrapper .section .box{
        display: block;
        box-sizing: border-box;
        width: 100%;
        /* border: 3px solid black; */
    }

    /* เเจ้งเตือนไม่กรอกข้อมูล */
    .wrapper .section .box .warning{
        color: red;
        text-align: center;
    }

    /* ทำ กล่องเล็กสุด เป็นกล่องเล็ก */
    .wrapper .section .flexbox-in{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        /* border: 3px solid black; */
    }
    .wrapper .section .box-in  {
        display: block;
        box-sizing: border-box;
        /* border: 3px solid black; */
        width: 50%;
    }

    /* กล่องเล็กสุด 2 กล่อง (อนุมัติไม่-อนุมัติ) */
    .wrapper .section .flexbox-inx{
        display: flex;
        box-sizing: border-box;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space-evenly;
        /* border: 3px solid black; */
    }

    .wrapper .section .box-inx  {
        display: block;
        box-sizing: border-box;
        justify-content: center;
        /* border: 3px solid black; */
    }

    button{
        background-color: #ffff;
        display: block;
        width: 30%;
        height: 100%;
        font-size: 22px;
    }

    /* Green */
    .wrapper .section .success {
        border-color: #04AA6D;
        color: green;
    }

    .wrapper .section .success:hover {
        background-color: #04AA6D;
        color: white;
    }

    /* Red */
    .wrapper .section .reject {
        border-color: #f44336;
        color: red;
    }

    .wrapper .section .reject:hover {
        background: #f44336;
        color: white;
    }

</style>

<div class="section">  <!-- แก้ในนี้ -->
    <div class = "flexbox2">
        <form action="" method="GET">
        <input type="hidden" name="controller" value="checkRG"/>
            <div class="flexbox">
                <div class="box">
                    <div class="table">
                        <b> รายละเอียดเพิ่มเติม </b>
                    </div>
                </div>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลใบคำร้อง</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">    
                        <div class="box-in">
                            <div class="content">
                                <b> รูปแปปใบคำร้อง : </b>
                                <b <?php if($requestForm->Request_Type == "ฝึกงาน"){
                                    echo " style = 'color:  #723C2A'";
                                }
                                else if($requestForm->Request_Type == "สหกิจศึกษา"){
                                    echo " style = 'color: #191970'";
                                }
                                ?>><?php echo $requestForm->Request_Type; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>ปีการศึกษาที่ยื่น : <?php echo $requestForm->Academic_Year; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>สถานะ : </b>
                                <b <?php if($requestForm->Request_Status == "อนุมัติ"){
                                    echo " style = 'color: green' ";
                                }
                                else if($requestForm->Request_Status == "ไม่อนุมัติ"){
                                    echo " style = 'color: #D30000'";
                                }
                                else if($requestForm->Request_Status == "อยู่ระหว่างดำเนินการพิจารณา"){
                                        echo " style = 'color:  #DFA006'";
                                }?>><?php echo $requestForm->Request_Status; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>วันที่ยื่นคำร้อง :  <?php echo date_format(date_create($requestForm->CreateDate),"d/m/Y")?> </b>
                            </div>
                        </div>
                        <div class="box-in" <?php if($requestForm->Request_Status != "ไม่อนุมัติ") echo " style='display: none'; ";?>>
                            <div class="content">
                                <b>เหตุผล : <?php echo $requestForm->Reject_Reason; ?></b>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลนิสิต</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">    
                        <div class="box-in">
                            <div class="content">
                                <b>ชื่อ-นามสกุล : <?php echo $requestForm->Requester->FirstName." ".$requestForm->Requester->LastName; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>เพศ : <?php echo $requestForm->Requester->Gender; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>รหัสนิสิต : <?php echo $requestForm->Requester->Student_Id; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>ชั้นปี:  <?php echo $requestForm->Student_Year; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>คณะ : <?php echo $requestForm->Requester->Student_Faculty; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>สาขา : <?php echo $requestForm->Requester->Student_Branch; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>เบอร์โทร : <?php echo $requestForm->PhoneNumber; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>ชื่อ Facebook : <?php echo $requestForm->FacebookName; ?></b>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
            
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลการฝึกงาน/สหกิจศึกษา</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">    
                        <div class="box-in">
                            <div class="content">
                                <b>ตำแหน่งที่ไปฝึกงาน : <?php echo $requestForm->Position; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <!--  -->
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>ค่าตอบแทน : <?php if($requestForm->Pay == 0) echo "-"; else echo $requestForm->Pay." บาท/วัน"; ?></b>
                                
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="contentDB">
                                <b>ที่พัก : <?php echo $requestForm->Department ; ?></b></b>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box">
                    <div class="content">
                        <b>ระยะเวลาการฝึกงาน/สหกิจศึกษาตั้งแต่วันที่ : <?php echo date_format(date_create($requestForm->Start_Date),"d/m/Y")?> ถึง <?php echo date_format(date_create($requestForm->End_Date),"d/m/Y")?> </b>
                    </div>
                </div> 
                <br>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลผู้รับหนังสือขอความอนุเคราะห์</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">    
                        <div class="box-in">
                            <div class="content">
                                <b>ชื่อ-นามสกุล : คุณ <?php echo $requestForm->Agent_FirstName." ".$requestForm->Agent_LastName; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>ตำแหน่ง : <?php echo $requestForm->Agent_Position ; ?></b>
                            </div>
                        </div>
                    </div>
                </div> 
                <br>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลผู้ประสานงาน</b>
                    </div>
                </div>
                <div class="box">
                    <div class="flexbox-in">    
                        <div class="box-in">
                            <div class="content">
                                <b>ชื่อ-นามสกุล : คุณ <?php echo $requestForm->Coordinator_FirstName." ".$requestForm->Coordinator_LastName; ?> </b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>อีเมล : <?php echo $requestForm->Coordinator_Email ; ?></b>
                            </div>
                        </div>
                        <div class="box-in">
                            <div class="content">
                                <b>เบอร์โทร : <?php echo $requestForm->Coordinator_PhoneNumber ; ?></b>
                            </div>
                        </div>
                    </div>
                </div> 
                <br>
                <div class="box">
                    <div class="contentHP">
                        <b>ข้อมูลที่อยู่สถานประกอบการ</b>
                    </div>
                </div> 
                <div class="box">
                    <div class="content">
                        <b>ชื่อสถานประกอบการ : <?php echo $requestForm->Company->Name ; ?></b>
                    </div>
                </div> 
                <div class="box">
                    <div class="content">
                        <b>ที่อยู่ : <?php echo $requestForm->Company->Address ; ?></b>
                    </div>
                </div> 
                <br>
                <div class="box">
                    <div class="flexbox-inx">
                            <button style=" border-radius: 7px;" class="success" type="submit" name="action" value="confirmApprove">อนุมัติ</button>
                            <button style=" border-radius: 7px;" class="reject" type="submit" name="action" value="confirmDisapprove">ไม่อนุมัติ</button>
                    </div>
                </div>
                <br>
            </div>
            <input type="hidden" name="requestFormID" value="<?php echo $requestForm->Request_Id; ?>"/>
        </form>
    </div>
</div>



