<?php

    class Amphure{

        public $Amphure_Id;
        public $Amphure_Code;
        public $Amphure_NameTH;
        public $Amphure_NameEN;
        public $Province_Id;

        public function __construct($Amphure_Id ,$Amphure_Code ,$Amphure_NameTH ,$Amphure_NameEN ,$Province_Id){
            $this->Amphure_Id = $Amphure_Id;
            $this->Amphure_Code = $Amphure_Code;
            $this->Amphure_NameTH = $Amphure_NameTH;
            $this->Amphure_NameEN = $Amphure_NameEN;
            $this->Province_Id = $Province_Id;
        }

        public static function getByID($Amphure_Id){
            require("connectionConnect.php");
            $sql = "SELECT * FROM amphure WHERE amphure.amphureID = '$Amphure_Id'";
            $result = $conn->query($sql);
            $my_row = $result->fetch_assoc();
            $Amphure_Id = $my_row["amphureID"];
            $Amphure_Code = $my_row["code"];
            $Amphure_NameTH = $my_row["nameTH"];
            $Amphure_NameEN = $my_row["nameEN"];
            $Province_Id = $my_row["provinceID"];

            require("connectionClose.php");
            return new Amphure($Amphure_Id ,$Amphure_Code ,$Amphure_NameTH ,$Amphure_NameEN ,$Province_Id);
        }

        public static function getByProvince($Province_Id){
            $amphureList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM amphure WHERE amphure.provinceID = '$Province_Id' ORDER BY amphure.nameTH";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Amphure_Id = $my_row["amphureID"];
                $Amphure_Code = $my_row["code"];
                $Amphure_NameTH = $my_row["nameTH"];
                $Amphure_NameEN = $my_row["nameEN"];
                $Province_Id = $my_row["provinceID"];

                $amphureList[] = new Amphure($Amphure_Id ,$Amphure_Code ,$Amphure_NameTH ,$Amphure_NameEN ,$Province_Id);
            }
            require("connectionClose.php");
            return $amphureList;
        }

    }
