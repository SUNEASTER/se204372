<?php

    class District{

        public $District_Id;
        public $District_ZipCode;
        public $District_NameTH;
        public $District_NameEN;
        public $Amphure_Id;

        public function __construct($District_Id ,$District_ZipCode ,$District_NameTH ,$District_NameEN ,$Amphure_Id){
            $this->District_Id = $District_Id;
            $this->District_ZipCode = $District_ZipCode;
            $this->District_NameTH = $District_NameTH;
            $this->District_NameEN = $District_NameEN;
            $this->Amphure_Id = $Amphure_Id;
        }

        public static function getByID($District_Id){
            require("connectionConnect.php");
            $sql = "SELECT * FROM district WHERE district.districtID = '$District_Id'";
            $result = $conn->query($sql);
            $my_row = $result->fetch_assoc();
            $District_Id = $my_row["districtID"];
            $District_ZipCode = $my_row["zipCode"];
            $District_NameTH = $my_row["nameTH"];
            $District_NameEN = $my_row["nameEN"];
            $Amphure_Id = $my_row["amphureID"];

            require("connectionClose.php");
            return new District($District_Id ,$District_ZipCode ,$District_NameTH ,$District_NameEN ,$Amphure_Id);
        }

        public static function getByAmphure($Amphure_Id){
            $districtList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM district WHERE district.amphureID = '$Amphure_Id' ORDER BY district.nameth";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $District_Id = $my_row["districtID"];
                $District_ZipCode = $my_row["zipCode"];
                $District_NameTH = $my_row["nameTH"];
                $District_NameEN = $my_row["nameEN"];
                $Amphure_Id = $my_row["amphureID"];

                $districtList[] = new District($District_Id ,$District_ZipCode ,$District_NameTH ,$District_NameEN ,$Amphure_Id);
            }
            require("connectionClose.php");
            return $districtList;
        }

    }
