<?php

    class Company{

        public $Company_Id;
        public $Name;
        public $Address;
        public $District;

        public function __construct($Company_Id, $Name, $Address, $District_Id){
            require_once("./models/districtModel.php");
            
            $this->Company_Id = $Company_Id;
            $this->Name = $Name;
            $this->Address = $Address;
            $this->District = District::getByID($District_Id);
        }

        public static function getByID($Company_Id){
            require("connectionConnect.php");
            $sql = "SELECT * FROM company WHERE company.companyID = '$Company_Id'";
            $result = $conn->query($sql);
            
            $my_row = $result->fetch_assoc();
            $Company_Id = $my_row["companyID"];
            $Name = $my_row["companyName"];
            $Address = $my_row["companyAddress"];
            $District_Id = $my_row["districtID"];

            require("connectionClose.php");
            return new Company($Company_Id, $Name, $Address, $District_Id);
        }

        public static function getByName($name){
            require("connectionConnect.php");
            $sql = "SELECT * FROM company WHERE company.companyName = '$name'";
            $result = $conn->query($sql);
            
            $my_row = $result->fetch_assoc();
            $Company_Id = $my_row["companyID"];
            $Name = $my_row["companyName"];
            $Address = $my_row["companyAddress"];
            $District_Id = $my_row["districtID"];

            require("connectionClose.php");
            return new Company($Company_Id, $Name, $Address, $District_Id);
        }

        public static function getAll(){
            $companyList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM company";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Company_Id = $my_row["companyID"];
                $Name = $my_row["companyName"];
                $Address = $my_row["companyAddress"];
                $District_Id = $my_row["districtID"];

                $companyList[] = new Company($Company_Id, $Name, $Address, $District_Id);
            }
            require("connectionClose.php");
            return $companyList;
        }

        public static function add($Name, $Address, $District_Id)
        {
            require("connectionConnect.php");
            $sql = "INSERT INTO company (companyID, companyName, companyAddress, districtID) 
                    VALUES (NULL, '$Name', '$Address', '$District_Id');";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

    }
