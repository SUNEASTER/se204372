<?php

    class User{

        public $Open_Id;
        public $User_Id;
        public $Password;
        public $FirstName;
        public $LastName;
        public $Student_Id;
        public $Student_Year;
        public $Student_Faculty;
        public $Student_Branch;
        public $Student_Status;
        public $YOS;
        public $Gender;
        public $User_Role;


        public function __construct($Open_Id, $User_Id, $Password, $FirstName, $LastName, $Student_Id, $Student_Faculty, $Student_Branch, $Student_Status, $YOS, $Gender, $User_Role){
            $this->Open_Id = $Open_Id;
            $this->User_Id = $User_Id;
            $this->Password = $Password;
            $this->FirstName = $FirstName;
            $this->LastName = $LastName;
            $this->Student_Id = $Student_Id;
            if($User_Role == "Student"){
                $dateOfBirth = "01-05-".$YOS;
                $today = date("Y-m-d");
                $diff = date_diff(date_create($dateOfBirth), date_create($today));
                $this->Student_Year = $diff->format('%y')+1;
                $date=date_create();
            }
            $this->Student_Faculty = $Student_Faculty;
            $this->Student_Branch = $Student_Branch;
            $this->Student_Status = $Student_Status;
            $this->YOS = $YOS;
            $this->Gender = $Gender;
            $this->User_Role = $User_Role;
        }

        public static function getByOpenID($Open_ID){
            require("connectionConnect.php");
            $sql = "SELECT * FROM useraccount WHERE useraccount.openID = '$Open_ID'";
            $result = $conn->query($sql);
            $my_row = $result->fetch_assoc();
            if( is_null($my_row) ) {
                require("connectionClose.php");
                return null;
            }
            $Open_Id = $my_row["openID"];
            $User_Id = $my_row["userID"];
            $Password = $my_row["password"];
            $FirstName = $my_row["firstName"];
            $LastName = $my_row["lastName"];
            $Student_Id = $my_row["studentID"];
            $Student_Faculty = $my_row["studentFaculty"];
            $Student_Branch = $my_row["studentBranch"];
            $Student_Status = $my_row["studentStatus"];
            $YOS = $my_row["YOS"];
            $Gender = $my_row["gender"];
            $User_Role = $my_row["userRole"];

            require("connectionClose.php");
            return new User($Open_Id, $User_Id, $Password, $FirstName, $LastName, $Student_Id, $Student_Faculty, $Student_Branch, $Student_Status, $YOS, $Gender, $User_Role);
        }

        public static function getByUserID($User_ID){
            require("connectionConnect.php");
            $sql = "SELECT * FROM useraccount WHERE useraccount.userID = '$User_ID'";
            $result = $conn->query($sql);
            $my_row = $result->fetch_assoc();
            if( is_null($my_row) ) {
                require("connectionClose.php");
                return null;
            }
            $Open_Id = $my_row["openID"];
            $User_Id = $my_row["userID"];
            $Password = $my_row["password"];
            $FirstName = $my_row["firstName"];
            $LastName = $my_row["lastName"];
            $Student_Id = $my_row["studentID"];
            $Student_Faculty = $my_row["studentFaculty"];
            $Student_Branch = $my_row["studentBranch"];
            $Student_Status = $my_row["studentStatus"];
            $YOS = $my_row["YOS"];
            $Gender = $my_row["gender"];
            $User_Role = $my_row["userRole"];

            require("connectionClose.php");
            return new User($Open_Id, $User_Id, $Password, $FirstName, $LastName, $Student_Id, $Student_Faculty, $Student_Branch, $Student_Status, $YOS, $Gender, $User_Role);   
        }

        public static function updateStudentStatus($Open_Id, $Student_Status)
        {
            require("connectionConnect.php");
            $sql = "UPDATE useraccount SET studentStatus = '$Student_Status' WHERE useraccount.openID = '$Open_Id'";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

    }
