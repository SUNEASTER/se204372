<?php

    class RequestForm{

        public $Request_Id;
        public $Requester;
        public $Request_Status;
        public $CreateDate;
        public $Academic_Year;
        public $Student_Year;
        public $Request_Type;
        public $Department;
        public $Pay;
        public $PhoneNumber;
        public $FacebookName;
        public $Position;
        public $Agent_FirstName;
        public $Agent_LastName;
        public $Agent_Position;
        public $Company;
        public $Coordinator_FirstName;
        public $Coordinator_LastName;
        public $Coordinator_PhoneNumber;
        public $Coordinator_Email;
        public $Start_Date;
        public $End_Date;
        public $Confirmer;
        public $Confirm_Date;
        public $Reject_Reason;

        public function __construct($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason){
            require_once("./models/userModel.php");
            require_once("./models/companyModel.php");

            $this->Request_Id = $Request_Id;
            $this->Requester = User::getByOpenID($Requester_OpenId);
            $this->Request_Status = $Request_Status;
            $this->CreateDate = $CreateDate;
            $year = (int)date_format(date_create($CreateDate),"Y");
            if((int)date("M") < 5)
                $year--;
            $this->Academic_Year = $year;
            $this->Student_Year = $year-$this->Requester->YOS+1;
            $this->Request_Type = $Request_Type;
            $this->Department = $Department;
            $this->Pay = $Pay;
            $this->PhoneNumber = $PhoneNumber;
            $this->FacebookName = $FacebookName;
            $this->Position = $Position;
            $this->Agent_FirstName = $Agent_FirstName;
            $this->Agent_LastName = $Agent_LastName;
            $this->Agent_Position = $Agent_Position;
            $this->Company = Company::getByID($Company_Id);
            $this->Coordinator_FirstName = $Coordinator_FirstName;
            $this->Coordinator_LastName = $Coordinator_LastName;
            $this->Coordinator_PhoneNumber = $Coordinator_PhoneNumber;
            $this->Coordinator_Email = $Coordinator_Email;
            $this->Start_Date = $Start_Date;
            $this->End_Date = $End_Date;
            $this->Confirmer = User::getByOpenID($Confirmer_OpenId);
            $this->Confirm_Date = $Confirm_Date;
            $this->Reject_Reason = $Reject_Reason;
        }

        public static function getByID($Request_Id){
            require("connectionConnect.php");
            $sql = "SELECT * FROM requestform WHERE requestform.requestID = '$Request_Id'";
            $result = $conn->query($sql);

            $my_row = $result->fetch_assoc();
            if( is_null($my_row) ) {
                require("connectionClose.php");
                return null;
            }
            $Request_Id = $my_row["requestID"];
            $Requester_OpenId = $my_row["requesterID"];
            $Request_Status = $my_row["requestStatus"];
            $CreateDate = $my_row["createDate"];
            $Request_Type = $my_row["requestType"];
            $Department = $my_row["department"];
            $Pay = $my_row["pay"];
            $PhoneNumber = $my_row["phoneNumber"];
            $FacebookName = $my_row["facebookName"];
            $Position = $my_row["position"];
            $Agent_FirstName = $my_row["agentFirstName"];
            $Agent_LastName = $my_row["agentLastName"];
            $Agent_Position = $my_row["agentPosition"];
            $Company_Id = $my_row["companyID"];
            $Coordinator_FirstName = $my_row["coordinatorFirstName"];
            $Coordinator_LastName = $my_row["coordinatorLastName"];
            $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
            $Coordinator_Email = $my_row["coordinatorEmail"];
            $Start_Date = $my_row["startDate"];
            $End_Date = $my_row["endDate"];
            $Confirmer_OpenId = $my_row["confirmerID"];
            $Confirm_Date = $my_row["confirmDate"];
            $Reject_Reason = $my_row["rejectReason"];

            require("connectionClose.php");
            return new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);   
        }

        public static function getAll(){
            $requestFormList = [];
            require("connectionConnect.php ORDER BY requestform.createDate DESC");
            $sql = "SELECT * FROM requestform";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function getByStatus($Request_Status){
            $requestFormList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM requestform WHERE requestform.requestStatus = '$Request_Status' ORDER BY requestform.createDate DESC";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function getByStatusAndTypeAndAcademicYear($Request_Status, $Request_Type, $Academic_Year){
            $requestFormList = [];
            require("connectionConnect.php");
            $checkFirst = " WHERE";
            $sql = "SELECT * FROM requestform";
            if($Request_Status != "ทั้งหมด"){
                $sql = $sql.$checkFirst." requestform.requestStatus = '$Request_Status'";
                $checkFirst = " AND";
            }
            if($Request_Type != "ทั้งหมด"){
                $sql = $sql.$checkFirst." requestform.requestType = '$Request_Type'";
                $checkFirst = " AND";
            }
            if($Academic_Year != "ทั้งหมด"){
                $sql = $sql.$checkFirst." IF(RIGHT(LEFT(requestform.createDate, 7), 2) < 5, LEFT(requestform.createDate, 4)-1, LEFT(requestform.createDate, 4)) = '$Academic_Year'";
            }
            $sql = $sql." ORDER BY requestform.createDate DESC";

            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function getByRequesterIDAndStatusAndTypeAndAcademicYear($Requester_OpenId, $Request_Status, $Request_Type, $Academic_Year){
            $requestFormList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM requestform WHERE requestform.requesterID = '$Requester_OpenId'";
            if($Request_Status != "ทั้งหมด"){
                $sql = $sql." AND requestform.requestStatus = '$Request_Status'";
            }
            if($Request_Type != "ทั้งหมด"){
                $sql = $sql." AND requestform.requestType = '$Request_Type'";
            }
            if($Academic_Year != "ทั้งหมด"){
                $sql = $sql." AND IF(RIGHT(LEFT(requestform.createDate, 7), 2) < 5, LEFT(requestform.createDate, 4)-1, LEFT(requestform.createDate, 4)) = '$Academic_Year'";
            }
            $sql = $sql." ORDER BY requestform.createDate DESC";

            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function getByRequesterID($Requester_OpenId){
            $requestFormList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM requestform WHERE requestform.requesterID = '$Requester_OpenId' ORDER BY requestform.createDate DESC";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function getLastestByRequesterID($Requester_OpenId){
            require("connectionConnect.php");
            $sql = "SELECT * FROM requestform WHERE requestform.requesterID = '$Requester_OpenId' ORDER BY requestform.createDate DESC";
            $result = $conn->query($sql);

            $my_row = $result->fetch_assoc();
            if( is_null($my_row) ) {
                require("connectionClose.php");
                return null;
            }
            $Request_Id = $my_row["requestID"];
            $Requester_OpenId = $my_row["requesterID"];
            $Request_Status = $my_row["requestStatus"];
            $CreateDate = $my_row["createDate"];
            $Request_Type = $my_row["requestType"];
            $Department = $my_row["department"];
            $Pay = $my_row["pay"];
            $PhoneNumber = $my_row["phoneNumber"];
            $FacebookName = $my_row["facebookName"];
            $Position = $my_row["position"];
            $Agent_FirstName = $my_row["agentFirstName"];
            $Agent_LastName = $my_row["agentLastName"];
            $Agent_Position = $my_row["agentPosition"];
            $Company_Id = $my_row["companyID"];
            $Coordinator_FirstName = $my_row["coordinatorFirstName"];
            $Coordinator_LastName = $my_row["coordinatorLastName"];
            $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
            $Coordinator_Email = $my_row["coordinatorEmail"];
            $Start_Date = $my_row["startDate"];
            $End_Date = $my_row["endDate"];
            $Confirmer_OpenId = $my_row["confirmerID"];
            $Confirm_Date = $my_row["confirmDate"];
            $Reject_Reason = $my_row["rejectReason"];

            require("connectionClose.php");
            return new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
            $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
        }

        public static function searchByRequesterIDAndStatusAndTypeAndAcademicYear($Requester_OpenId, $Request_Status, $Request_Type, $Academic_Year, $key){
            $requestFormList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM ((requestform AS r LEFT JOIN useraccount AS u ON r.requesterID=u.openID) LEFT JOIN company AS c ON r.companyID = c.companyID) WHERE r.requesterID = '$Requester_OpenId'";
            if($Request_Status != "ทั้งหมด"){
                $sql = $sql." AND r.requestStatus = '$Request_Status'";
            }
            if($Request_Type != "ทั้งหมด"){
                $sql = $sql." AND r.requestType = '$Request_Type'";
            }
            if($Academic_Year != "ทั้งหมด"){
                $sql = $sql." AND IF(RIGHT(LEFT(r.createDate, 7), 2) < 5, LEFT(r.createDate, 4)-1, LEFT(r.createDate, 4)) = '$Academic_Year'";
            }
            $sql = $sql." AND (CONCAT(u.firstName,' ',u.lastName) LIKE '%$key%' OR c.companyName LIKE '%$key%' OR r.requestStatus LIKE '%$key%')";
            $sql = $sql." ORDER BY r.createDate DESC";

            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function searchByStatusAndTypeAndAcademicYear($Request_Status, $Request_Type, $Academic_Year, $key){
            $requestFormList = [];
            require("connectionConnect.php");
            $checkFirst = " WHERE";
            $sql = "SELECT * FROM ((requestform AS r LEFT JOIN useraccount AS u ON r.requesterID=u.openID) LEFT JOIN company AS c ON r.companyID = c.companyID) ";
            if($Request_Status != "ทั้งหมด"){
                $sql = $sql.$checkFirst." r.requestStatus = '$Request_Status'";
                $checkFirst = " AND";
            }
            if($Request_Type != "ทั้งหมด"){
                $sql = $sql.$checkFirst." r.requestType = '$Request_Type'";
                $checkFirst = " AND";
            }
            if($Academic_Year != "ทั้งหมด"){
                $sql = $sql.$checkFirst." IF(RIGHT(LEFT(r.createDate, 7), 2) < 5, LEFT(r.createDate, 4)-1, LEFT(r.createDate, 4)) = '$Academic_Year'";
                $checkFirst = " AND";
            }
            $sql = $sql.$checkFirst." (CONCAT(u.firstName,' ',u.lastName) LIKE '%$key%' OR c.companyName LIKE '%$key%' OR r.requestStatus LIKE '%$key%')";
            $sql = $sql." ORDER BY r.createDate DESC";

            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Request_Id = $my_row["requestID"];
                $Requester_OpenId = $my_row["requesterID"];
                $Request_Status = $my_row["requestStatus"];
                $CreateDate = $my_row["createDate"];
                $Request_Type = $my_row["requestType"];
                $Department = $my_row["department"];
                $Pay = $my_row["pay"];
                $PhoneNumber = $my_row["phoneNumber"];
                $FacebookName = $my_row["facebookName"];
                $Position = $my_row["position"];
                $Agent_FirstName = $my_row["agentFirstName"];
                $Agent_LastName = $my_row["agentLastName"];
                $Agent_Position = $my_row["agentPosition"];
                $Company_Id = $my_row["companyID"];
                $Coordinator_FirstName = $my_row["coordinatorFirstName"];
                $Coordinator_LastName = $my_row["coordinatorLastName"];
                $Coordinator_PhoneNumber = $my_row["coordinatorPhoneNumber"];
                $Coordinator_Email = $my_row["coordinatorEmail"];
                $Start_Date = $my_row["startDate"];
                $End_Date = $my_row["endDate"];
                $Confirmer_OpenId = $my_row["confirmerID"];
                $Confirm_Date = $my_row["confirmDate"];
                $Reject_Reason = $my_row["rejectReason"];

                $requestFormList[] = new RequestForm($Request_Id, $Requester_OpenId, $Request_Status, $CreateDate, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                                    $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email, $Confirmer_OpenId, $Confirm_Date, $Reject_Reason);  
            }
            require("connectionClose.php");
            return $requestFormList;
        }

        public static function add($Requester_OpenId, $Request_Type, $Department, $Pay, $PhoneNumber, $FacebookName, $Position, $Start_Date, $End_Date,
                                $Agent_FirstName, $Agent_LastName, $Agent_Position, $Company_Id, $Coordinator_FirstName, $Coordinator_LastName, $Coordinator_PhoneNumber, $Coordinator_Email)
        {
            require("connectionConnect.php");
            $sql = "INSERT INTO `requestform` (requestID, requesterID, requestStatus, createDate, requestType, department, pay, phoneNumber, facebookName, position, agentFirstName, agentLastName, agentPosition, companyID, coordinatorFirstName, coordinatorLastName, coordinatorPhoneNumber, coordinatorEmail, startDate, endDate, confirmerID, confirmDate, rejectReason) 
                    VALUES (NULL, '$Requester_OpenId', 'อยู่ระหว่างดำเนินการพิจารณา', current_timestamp(), '$Request_Type', '$Department', '$Pay', '$PhoneNumber', '$FacebookName', '$Position', '$Agent_FirstName', '$Agent_LastName', '$Agent_Position', '$Company_Id', '$Coordinator_FirstName', '$Coordinator_LastName', '$Coordinator_PhoneNumber', '$Coordinator_Email', '$Start_Date', '$End_Date', NULL, NULL, NULL)";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

        public static function updateStatus($Request_Id, $Request_Status)
        {
            require("connectionConnect.php");
            $sql = "UPDATE requestform SET requestStatus = '$Request_Status' WHERE requestform.requestID = $Request_Id";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

        public static function updateConfirmer($Request_Id, $Confirmer_OpenId)
        {
            require("connectionConnect.php");
            $sql = "UPDATE requestform SET confirmerID = '$Confirmer_OpenId', confirmDate = current_timestamp() WHERE requestform.requestID = $Request_Id";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

        public static function updateRejectReason($Request_Id, $Reject_Reason)
        {
            require("connectionConnect.php");
            $sql = "UPDATE requestform SET rejectReason = '$Reject_Reason' WHERE requestform.requestID = $Request_Id";
            $result = $conn->query($sql);
            require("connectionClose.php");
        }

    }
