<?php

    class Province{

        public $Province_Id;
        public $Province_Code;
        public $Province_NameTH;
        public $Province_NameEN;

        public function __construct($Province_Id ,$Province_Code ,$Province_NameTH ,$Province_NameEN){
            $this->Province_Id = $Province_Id;
            $this->Province_Code = $Province_Code;
            $this->Province_NameTH = $Province_NameTH;
            $this->Province_NameEN = $Province_NameEN;
        }

        public static function getByID($Province_Id){
            require("connectionConnect.php");
            $sql = "SELECT * FROM province WHERE province.provinceID = '$Province_Id'";
            $result = $conn->query($sql);
            $my_row = $result->fetch_assoc();
            $Province_Id = $my_row["provinceID"];
            $Province_Code = $my_row["code"];
            $Province_NameTH = $my_row["nameTH"];
            $Province_NameEN = $my_row["nameEN"];

            require("connectionClose.php");
            return new Province($Province_Id ,$Province_Code ,$Province_NameTH ,$Province_NameEN);
        }

        public static function getAll(){
            $provinceList = [];
            require("connectionConnect.php");
            $sql = "SELECT * FROM province ORDER BY province.nameTH";
            $result = $conn->query($sql);
            while ($my_row = $result->fetch_assoc()) {
                $Province_Id = $my_row["provinceID"];
                $Province_Code = $my_row["code"];
                $Province_NameTH = $my_row["nameTH"];
                $Province_NameEN = $my_row["nameEN"];

                $provinceList[] = new Province($Province_Id ,$Province_Code ,$Province_NameTH ,$Province_NameEN);
            }
            require("connectionClose.php");
            return $provinceList;
        }

    }
