<?php
    require_once("./models/amphureModel.php");
    $Province_Id = $_GET['Province_Id'];
    $Amphure_list = Amphure::getByProvince($Province_Id);
    $count = count($Amphure_list);
    echo "<option hidden='hidden' value=0>เลือกอำเภอ</option>";
    foreach($Amphure_list as $amphure){
        echo "<option value=$amphure->Amphure_Id>$amphure->Amphure_NameTH</option>";
    }
?>