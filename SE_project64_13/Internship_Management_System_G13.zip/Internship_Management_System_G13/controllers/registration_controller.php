<?php
class RegistrationController
{
    public function index()
    {
        $openID = $_SESSION["openID"];
        $user = User::getByOpenID($openID);
        require_once("./views/nabbar.php");
        if($user->Student_Status == "ระหว่างดำเนินการพิจารณา"){
            require_once("./views/register/waitingRegister.php");
        }
        else if($user->Student_Status == "ไม่อนุมัติ"){
            $rejectReason = RequestForm::getLastestByRequesterID($openID)->Reject_Reason;
            require_once("./views/register/rejectRegister.php");
        }
        else if($user->Student_Status == "ยื่นเอกสาร"){
            $year = (int)date("Y") ;
            if((int)date("M") < 5)
                $year--;
            $company_list = Company::getAll();
            $Province_list = Province::getAll();
            require_once("./views/register/registration.php");
        }
        else{
            require_once("./views/register/passRegister.php");
        }

    }

    public function register(){
        $openID = $_SESSION["openID"];
        $type = $_GET['type'];
        $studentPhone = $_GET['studentPhone'];
        $nameFB = $_GET['nameFB'];
        $jobTitle = $_GET['jobTitle'];
        $com = $_GET['com'];
        $money = 0;
        if($com == "มี")
            $money = $_GET['money'];
        $hotel = $_GET['hotel'];
        $dateStart = $_GET['dateStart'];
        $dateEnd = $_GET['dateEnd'];
        $FnameRecipient = $_GET['FnameRecipient'];
        $LnameRecipient = $_GET['LnameRecipient'];
        $recipientPosition = $_GET['recipientPosition'];
        $FnameCoordinator = $_GET['FnameCoordinator'];
        $LnameCoordinator = $_GET['LnameCoordinator'];
        $coordinatorPhone = $_GET['coordinatorPhone'];
        $coordinatorEmail = $_GET['coordinatorEmail'];
        $company_id = $_GET['company_id'];
        $recipientPosition = $_GET['recipientPosition'];
        if(isset($_GET['newCompany'])){
            $nameCompany = $_GET['nameCompany'];
            $numAddress = $_GET['numAddress'];
            $street = $_GET['street'];
            $province_id = $_GET['province_id'];
            $amphure_id = $_GET['amphure_id'];
            $district_id = $_GET['district_id'];
            if($street != "")
                $street = " ถ.".$street;
            $province = Province::getById($province_id);
            $amphure = Amphure::getById($amphure_id);
            $district = District::getById($district_id);
            $address = $numAddress.$street." ต.".$district->District_NameTH." อ.".$amphure->Amphure_NameTH." จ.".$province->Province_NameTH." ".$district->District_ZipCode;
            Company::add($nameCompany, $address, $district->District_Id);
            $company = Company::getByName($nameCompany);
            $company_id = $company->Company_Id;
        }
        
        RequestForm::add($openID, $type, $hotel, $money, $studentPhone, $nameFB, $jobTitle, $dateStart, $dateEnd, $FnameRecipient, $LnameRecipient, $recipientPosition, $company_id, $FnameCoordinator, $LnameCoordinator, $coordinatorPhone, $coordinatorEmail);
        User::updateStudentStatus($openID,"ระหว่างดำเนินการพิจารณา");

        header("Location: ?controller=registration&action=index");
        die();
    }

    public function reapply(){
        $openID = $_SESSION["openID"];

        User::updateStudentStatus($openID, "ยื่นเอกสาร");

        header("Location: ?controller=registration&action=index");
        die();
    }
    
}