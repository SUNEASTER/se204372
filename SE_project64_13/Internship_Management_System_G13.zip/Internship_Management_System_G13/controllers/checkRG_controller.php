<?php
class CheckRGController
{
    public function index(){
        $openID = $_SESSION["openID"];
        $user = User::getByOpenID($openID);
        $requestType = "ทั้งหมด";
        if(isset($_GET['requestType']))
            $requestType =  $_GET['requestType'];
        $academicYear =  "ทั้งหมด";
        if(isset($_GET['academicYear']))
            $academicYear =  $_GET['academicYear'];
        $key =  "";
        if(isset($_GET['key'])){
            $key =  $_GET['key'];
            $requestForm_list_all = RequestForm::searchByStatusAndTypeAndAcademicYear("อยู่ระหว่างดำเนินการพิจารณา", $requestType, $academicYear, $key);
        }
        else
            $requestForm_list_all = RequestForm::getByStatusAndTypeAndAcademicYear("อยู่ระหว่างดำเนินการพิจารณา", $requestType, $academicYear);
            
        $num_item = count($requestForm_list_all);
        $page = 1;
        if(isset($_GET['page']))
            $page = $_GET['page'];
        $num_row = 5;
        $max_page = ceil($num_item/$num_row);
        if($max_page == 0)
            $max_page = 1;

        $requestForm_list = [];

        for($x = $num_row*($page-1) ; $x < $num_row*$page ; $x++){
            if($x >= $num_item)
                break;
            array_push($requestForm_list,$requestForm_list_all[$x]) ;
        }
        $Request_Type_DropDown = array("ทั้งหมด","ฝึกงาน","สหกิจศึกษา");
        $history_year = 5;
        
        $year = (int)date("Y") ;
        if((int)date("M") < 5)
            $year--;
        $Academic_Year_DropDown = array();
      
        for( $i=0 ; $i < $history_year ; $i++){
            array_push($Academic_Year_DropDown ,($year-$i));
        }
    
        require_once("./views/nabbar.php");
        require_once("./views/checkRG/index_checkRG.php");
    }

    public function detail(){
        $openID = $_SESSION["openID"];
        $user = User::getByOpenID($openID);
        $requestFormID = $_GET['requestFormID'];
        $requestForm = RequestForm::getByID($requestFormID);
        if(is_null($requestForm)){
            header("Location: ?controller=checkRG&action=index");
            die();
        }
        require_once("./views/nabbar.php");
        require_once("./views/checkRG/checkUserDetail.php");
    }

    public function confirmApprove(){
        $openID = $_SESSION["openID"];
        $user = User::getByOpenID($openID);
        $requestFormID = $_GET['requestFormID'];
        $requestForm = RequestForm::getByID($requestFormID);

        require_once("./views/nabbar.php");
        require_once("./views/checkRG/confirmApprove_checkRG.php");
    }

    public function confirmDisapprove(){
        $openID = $_SESSION["openID"];
        $user = User::getByOpenID($openID);
        $requestFormID = $_GET['requestFormID'];
        $requestForm = RequestForm::getByID($requestFormID);

        require_once("./views/nabbar.php");
        require_once("./views/checkRG/confirmDisapprove_checkRG.php");
    }

    public function approve(){
        $openID = $_SESSION["openID"];
        $requestFormID = $_GET['requestFormID'];
        $requestForm = RequestForm::getByID($requestFormID);

        User::updateStudentStatus($requestForm->Requester->Open_Id, "ยื่นขอความอนุเคราะห์ไปบริษัท");
        RequestForm::updateStatus($requestFormID, "อนุมัติ");
        RequestForm::updateConfirmer($requestFormID, $openID);

        header("Location: ?controller=checkRG&action=index");
        die();
    }

    public function disapprove(){
        $openID = $_SESSION["openID"];
        $requestFormID = $_GET['requestFormID'];
        $rejectReason = $_GET['Reason_id'];
        if ($rejectReason == "อื่นๆ")
            $rejectReason = $_GET['other'];
        $requestForm = RequestForm::getByID($requestFormID);

        User::updateStudentStatus($requestForm->Requester->Open_Id, "ไม่อนุมัติ");
        RequestForm::updateStatus($requestFormID, "ไม่อนุมัติ");
        RequestForm::updateConfirmer($requestFormID, $openID);
        RequestForm::updateRejectReason($requestFormID, $rejectReason);

        header("Location: ?controller=checkRG&action=index");
        die();
    }
}